# NeurIPS 2026 manuscript

`main.tex` uses the unmodified official NeurIPS 2026 main-track submission
style from the conference formatting kit. The requested author-listed build is
line-numbered, limited to nine main-text pages, and followed by references,
technical appendices, and the completed NeurIPS checklist.

Numerical prose is evidence-gated. `analyze.py` creates
`generated/results.tex` from saved held-out predictions; the remaining
generated fragments are written only after artifact-level validation.

Compile and stage the deliverable with:

```bash
cd paper
make all
```

The final PDF is written to
`output/pdf/huginn_monitorability_neurips2026.pdf`; intermediates remain under
`tmp/pdfs/`. A self-contained source tree is written to
`output/latex/huginn_monitorability_neurips2026/`; it includes the manuscript,
bibliography, official style, completed checklist, generated result fragments,
and vector PDF figures in the relative directory structure expected by
`main.tex`. The same tree is archived as
`output/latex/huginn_monitorability_neurips2026.zip`.

Official format source:
https://media.neurips.cc/Conferences/NeurIPS2026/Formatting_Instructions_For_NeurIPS_2026.zip
